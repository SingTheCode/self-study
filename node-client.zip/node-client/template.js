export default function template(body) {
  return `
  <!DOCTYPE html>
  <html>
    <head>
      <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
      <title>Document</title>
    </head>
    <body>
      ${body}
    </body>
  </html>
    `;
}
