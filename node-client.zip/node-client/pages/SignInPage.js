export default function SignInPage() {
  return `
    <h1>회원가입 ㄱㄱ</h1>
    <input id="name"></input>
    <input id="pw"></input>
    <button id="submit">회원가입</button>
    <script type="module" src="./pages/signIn.js"></script>
  `;
}
