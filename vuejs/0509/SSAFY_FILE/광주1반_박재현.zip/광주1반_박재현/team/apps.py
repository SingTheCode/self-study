from django.apps import AppConfig


class TeamConfig(AppConfig):
    name = 'team'
